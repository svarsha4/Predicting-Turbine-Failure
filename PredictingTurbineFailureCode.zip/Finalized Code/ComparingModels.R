rm(list=ls())

library(fmsb)
library(randomForest)
library(pROC)
library(ggplot2)
library(lubridate)
library(tidyverse)
library(gridExtra)
library(dplyr)

merged_data <- read.csv("final_dataset2.csv", stringsAsFactors = TRUE)

####NTesting Prep############
#load in the forest not trained with knowledge of the turbines
load("NoTurbineForest.RData")

#recreating the testing data from the no turbine forest
NTesting <- subset(merged_data, select = -c(date))
RNGkind(sample.kind = "default")
set.seed(45698654)
train.idx <- sample(x = 1:nrow(NTesting), size = floor(.7*nrow(NTesting)))
NTesting.df <- NTesting[-train.idx,]
NTesting.df$FaultCodeOccurs <- as.factor(NTesting.df$FaultCodeOccurs)

#creates a column, pred, which is the forest's predicted probability of a fault code occuring within
#the next 24 hours
NTesting.df$predict <- NA
NTesting.df$predict <- predict(NoTurbineForest, NTesting.df, type = "prob")[,"1"]

#If the probability of a fault is more than .418, then pred becomes a 1. Otherwise, it's a 0. 
#.418 was decided on using the ROC curve
NTesting.df$pred <- as.factor(ifelse(NTesting.df$predict>.418, 1, 0))
#creates a column, correct, that identifies if pred was correct or not in its prediction
NTesting.df$correct <- NA
NTesting.df$correct <- as.factor(ifelse(NTesting.df$pred == NTesting.df$FaultCodeOccurs, 1, 0))

#creates 2 new columns, sensitivityhelp and specificityhelp
NTesting.df$sensitivityhelp <- NA
NTesting.df$specificityhelp <- NA

#sensitivityhelp is a 1 when the model correctly predicted a fault, and a 0 otherwise
#specificityhelp is a 0 when the modol correctly predicted a lack of fault, and a 0 otherwise
NTesting.df$sensitivityhelp <- ifelse(NTesting.df$correct == 1 & NTesting.df$FaultCodeOccurs== 1, 1, 0)
NTesting.df$specificityhelp <- ifelse(NTesting.df$correct == 1 & NTesting.df$FaultCodeOccurs== 0, 1, 0)

#creates a new dataframe N(o turbine) S(ensitivity) S(pecificity) By Type
#this datafram holds the sensitivity and specifity for all rows where the next fault code to occur
#is of each type, as well as the number instances where the next fault code is of each type
NSSByType <- NTesting.df %>% group_by(FaultCodeType) %>%
  summarise(sensitivity = sum(as.numeric(sensitivityhelp))/sum(FaultCodeOccurs == 1), 
            specificity = sum(as.numeric(specificityhelp))/sum(FaultCodeOccurs == 0),
            n = n())

#creates a new column, BinTimeToFault, that rounds the time until fault to the nearest hour
NTesting.df$BinTimeToFault <- round(NTesting.df$TimeUntilFault)

#This creates a new dataframe N(o turbine) T(ime) T(o) F(ault) Test
#It keeps track of the average prediction for each binned hour, as well as how many rows fall into that bin
NTTFTest <- NTesting.df %>% group_by(BinTimeToFault) %>%
  summarise(prediction = sum(as.numeric(pred))/n()-1,
            n = n())

#This creates a new dataframe N(o turbine) S(ensitivity) S(pecificity) By Turbine
#It keeps track of the sensitivity and specificity for the models predictions on each turbine, as well
#as the number of readings for each one
NSSByTurbine <- NTesting.df %>% group_by(TurbineId) %>%
  summarise(sensitivity = sum(as.numeric(sensitivityhelp))/sum(FaultCodeOccurs == 1), 
            specificity = sum(as.numeric(specificityhelp))/sum(FaultCodeOccurs == 0),
            n = n())

####Testing Prep####
#this repeats the same process, but on the model that was trained with knowledge of turbines
load("TurbineForest.RData")
TurbineForest <- finalForest
rm(finalForest)

testing <- subset(merged_data, select = -c(date))
RNGkind(sample.kind = "default")
set.seed(2291352)
train.idx <- sample(x = 1:nrow(testing), size = floor(.7*nrow(testing)))
testing.df <- testing[-train.idx,]
testing.df$FaultCodeOccurs <- as.factor(testing.df$FaultCodeOccurs)

testing.df$predict <- NA
testing.df$predict <- predict(TurbineForest, testing.df, type = "prob")[,"1"]

testing.df$pred <- as.factor(ifelse(testing.df$pred>.491, 1, 0))
testing.df$correct <- NA
testing.df$correct <- as.factor(ifelse(testing.df$pred == testing.df$FaultCodeOccurs, 1, 0))
testing.df$sensitivityhelp <- NA
testing.df$specificityhelp <- NA

testing.df$sensitivityhelp <- ifelse(testing.df$correct == 1 & testing.df$FaultCodeOccurs== 1, 1, 0)
testing.df$specificityhelp <- ifelse(testing.df$correct == 1 & testing.df$FaultCodeOccurs== 0, 1, 0)

SSByType <- testing.df %>% group_by(FaultCodeType) %>%
  summarise(sensitivity = sum(as.numeric(sensitivityhelp))/sum(FaultCodeOccurs == 1),
            specificity = sum(as.numeric(specificityhelp))/sum(FaultCodeOccurs == 0),
            n = n())


testing.df$BinTimeToFault <- round(testing.df$TimeUntilFault)

TTFTest <- testing.df %>% group_by(BinTimeToFault) %>%
  summarise(prediction = sum(as.numeric(pred))/n()-1,
            n = n())

SSByTurbine <- testing.df %>% group_by(TurbineId) %>%
  summarise(sensitivity = sum(as.numeric(sensitivityhelp))/sum(FaultCodeOccurs == 1), 
            specificity = sum(as.numeric(specificityhelp))/sum(FaultCodeOccurs == 0),
            n = n())

####Comparison######
#Adds in a new column to each of the created datasets that specifies which model it used
NSSByType['ModelName'] <- "Without Turbine"
SSByType['ModelName'] <- "With Turbine"

NTTFTest['ModelName'] <- "Without Turbine"
TTFTest['ModelName'] <- "With Turbine"

NSSByTurbine['ModelName'] <- "Without Turbine"
SSByTurbine['ModelName'] <- "With Turbine"


#Adds the type comparison datasets to each other, each row being a unique fault code type and model combination
SSByTypeCombo <- rbind(SSByType, NSSByType)
#Adds the time to fault testing datasets to each other, with 2 rows for each time to fault, one for each model
TTFTestCombo <- rbind(TTFTest, NTTFTest)
#Adds the turbine comparison datasets to each other, each row being a unique combination of turbine id and model
SSByTurbineCombo <- rbind(NSSByTurbine, SSByTurbine)


#creates a plot that shows how accurately each model predicts the existence of each fault code type
ggplot(data = SSByTypeCombo, aes(x=reorder(FaultCodeType, sensitivity), y=sensitivity, fill=ModelName))+
  geom_bar(position="dodge", stat="identity", width=.5)+
  scale_y_continuous(expand = c(0,0))+
  labs(x="Fault Code Type", y = "Probability of Correctly Predicting a Fault", title="Model Performance by Fault Code Type")+
  scale_fill_manual(values=c("#FF0000", "#000000"))+
  guides(fill=guide_legend(title="Model Output"))+
  theme_classic()

#https://stackoverflow.com/questions/20220424/ggplot2-bar-plot-no-space-between-bottom-of-geom-and-x-axis-keep-space-above
#used this to help make the bars start at the bottom of the graph

#creates a line plot that shows how likely each model is to predict a fault, across the true time to fault
#adds in a blue vertical line at the 24 cutoff mark. Ideally, at this line, the models go from predicting
#1's to predicting 0's. 
ggplot(data=TTFTestCombo %>% filter(BinTimeToFault < 100), aes(x=BinTimeToFault, y=prediction, group=ModelName)) +
  geom_line(aes(color=ModelName), size=1.5)+
  scale_y_continuous(expand = c(0,0))+
  scale_color_manual(values=c('Red', 'Black'))+
  geom_vline(xintercept=24, color="Blue")+
  labs(x="True Time to Fault", y="Percentage of Time Model Predicts a Fault", title="Model Outputs Leading Up to a Fault")+
  guides(color=guide_legend(title="Model Output"))+
  annotate(geom="text", x = 29, y=.8, label="24 hour dividing line", color="blue")+
  scale_x_reverse(expand = c(0,0))+
  theme_bw()

#creates 2 plots that shows how accurately each model predicts the presense (or not) of a fault for each turbine 
p3 <- ggplot(data = SSByTurbineCombo, aes(x=TurbineId, y=sensitivity, fill=ModelName))+
  geom_bar(position="dodge", stat="identity", width=.5)+
  labs(x="Fault Code Type", y = "Probability of Correctly Predicting a Fault")+
  scale_fill_manual(values=c("#FF0000", "#000000"))+
  guides(fill=guide_legend(title="Model Output"))+
  theme_bw()

p4 <- ggplot(data = SSByTurbineCombo, aes(x=TurbineId, y=specificity, fill=ModelName))+
  geom_bar(position="dodge", stat="identity", width=.5)+
  labs(x="Fault Code Type", y = "Probability of Correctly Predicting No Fault")+
  scale_fill_manual(values=c("#FF0000", "#000000"))+
  guides(fill=guide_legend(title="Model Output"))+
  theme_bw()

grid.arrange(p3, p4)
#This wasn't particularly interesting, and was not added into the presentation


