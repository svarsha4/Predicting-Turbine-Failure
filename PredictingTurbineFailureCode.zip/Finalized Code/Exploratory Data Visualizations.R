# new visualizations
rm(list = ls())
data2 <- read.csv("new_data_weather_6_hour_delay_binary.csv", stringsAsFactors = T)

data <- read.csv("merged_data_all_sensor_readings_weather_metrics_imputed_is_fault_code_24_hours.csv", stringsAsFactors = T)
View(data)

#loading packages
library(ggplot2)
library(lubridate)
library(tidyverse)
library(gridExtra)
library(dplyr)
library(hrbrthemes)
library(ggExtra)
library(RColorBrewer)
library(heatmaply)
library(ggridges)
library(viridis)
library(tibbletime)
library(anomalize)
library(hexbin)
library(gganimate)


summary(data$FaultCodeType)
summary(data$FaultCodeDescription)

sum(data$FaultCodeOccurs)






# Going to now do Visuals with the new filter that gets ride of informational, NA and human performance 
NOINFO <- data %>%
  filter(!FaultCodeType %in% c("Informational", "NA", "Human Performance")) %>%
  na.omit()

cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7", "#000000", "#FF3300","#FFFFFF","#996666","#FF00CC")


BP_RPM_NEW_V <- ggplot(NOINFO,aes(x = FaultCodeType, y = AverageGeneratorRPM, fill = FaultCodeType))+
  geom_boxplot(outlier.color = "black", outlier.shape = 1, fatten = 1.5)+
  # To use for fills, add
  scale_fill_manual(values=cbPalette) +
  labs(title = "Fault code type by rpm", x= "FaultCodeType", y ="RPM")+
  theme_dark()+
  theme(plot.title = element_text(hjust = 1, size = 16),
        axis.title.x = element_text(size = 14),
        axis.title.y = element_text(size = 14),
        axis.text = element_text(size = 5),
        legend.position = 'none')

BP_POWER_NEW_V <- ggplot(NOINFO,aes(x = FaultCodeType, y = AverageActivePower, fill = FaultCodeType))+
  geom_boxplot(outlier.color = "black", outlier.shape = 1, fatten = 1.5)+
  # To use for fills, add
  scale_fill_manual(values=cbPalette) +
  labs(title = "Fault code type by active power", x= "FaultCodeType", y ="Active Power")+
  theme_dark()+
  theme(plot.title = element_text(hjust = 1, size = 16),
        axis.title.x = element_text(size = 14),
        axis.title.y = element_text(size = 14),
        axis.text = element_text(size = 5),
        legend.position = 'none')


grid.arrange(BP_POWER_NEW_V, BP_RPM_NEW_V)
##############################################################

# Area + contour
ggplot(NOINFO, aes(x=AverageActivePower, y=AverageGeneratorRPM) ) +
  stat_density_2d(aes(fill = FaultCodeType), geom = "polygon", colour="white")

# Area + contour - I like this one 
ggplot(NOINFO, aes(x=AverageGearboxHSBearingTemperature, y=AverageGearboxIMSBearingTemperature) ) +
  stat_density_2d(aes(fill = FaultCodeType), geom = "polygon", colour="white")





View(data)
##################################################################################

# # linear trend + confidence interval
ggplot(NOINFO, aes(x=SdHydraulicPressure, y=SdGearboxOilTemperature)) +
  geom_point() +
  geom_smooth(method=lm , color="red", fill="#56B4E9", se=TRUE) +
  theme_dark()


# Area + contour - I like this one 
ggplot(NOINFO, aes(x=SdHydraulicPressure, y=SdGearboxOilTemperature) ) +
  stat_density_2d(aes(fill = FaultCodeType), geom = "polygon", colour="white")











# THIS LINE OF CODE FILTERS THE FAULT CODE TYPE BY THE 3 MOST COMMON
temp <- filter(NOINFO, FaultCodeType %in% tail(names(sort(table(NOINFO$FaultCodeType))),3)) # takes the 3 most common faults


turbine_info$

















































