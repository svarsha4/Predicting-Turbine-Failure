# new visualizations on the new data
rm(list = ls())

finaldataset <- read.csv("final_dataset.csv",stringsAsFactors = T)


View(finaldataset)
summary(finaldataset)

#loading packages
library(ggplot2)
library(lubridate)
library(tidyverse)
library(gridExtra)
library(dplyr)
library(hrbrthemes)
library(ggExtra)
library(RColorBrewer)
library(heatmaply)
library(ggridges)
library(viridis)
library(tibbletime)
library(anomalize)
library(hexbin)
library(gganimate)
library(GGally)


# Going to now do Visuals with the new filter that gets ride of informational, NA and human performance 
NOINFO <- finaldataset %>%
  filter(!FaultCodeType %in% c("Informational", "NA", "Human Performance")) %>%
  na.omit()


display.brewer.all(colorblindFriendly = TRUE)
# which sensor readings and environmental conditions resuults in the highest number of fault codes to occur
# MULTIVARIATE VISUALIZATIONS #

# how many nas in the column - should be none  
sum(is.na(new_data_complete_merged$AverageActivePower))
##########################################################

# BOXPLOT VERTICAL 

BP_RPM_NEW_V <- ggplot(NOINFO,aes(x = FaultCodeType, y = AverageGeneratorRPM, fill = FaultCodeType))+
  geom_boxplot(outlier.color = "black", outlier.shape = 1, fatten = 1.5)+
  # To use for fills, add
  scale_fill_brewer(palette = "Paired") +
  labs(title = "Fault code type by rpm", x= "FaultCodeType", y ="RPM")+
  theme_dark()+
  theme(plot.title = element_text(hjust = 1, size = 16),
        axis.title.x = element_text(size = 14),
        axis.title.y = element_text(size = 14),
        axis.text = element_text(size = 5),
        legend.position = 'none')

BP_POWER_NEW_V <- ggplot(NOINFO,aes(x = FaultCodeType, y = AverageActivePower, fill = FaultCodeType))+
  geom_boxplot(outlier.color = "black", outlier.shape = 1, fatten = 1.5)+
  # To use for fills, add
  scale_fill_brewer(palette = "Paired") +
  labs(title = "Fault code type by active power", x= "FaultCodeType", y ="Active Power")+
  theme_dark()+
  theme(plot.title = element_text(hjust = 1, size = 16),
        axis.title.x = element_text(size = 14),
        axis.title.y = element_text(size = 14),
        axis.text = element_text(size = 5),
        legend.position = 'none')


grid.arrange(BP_POWER_NEW_V, BP_RPM_NEW_V)
###################################################

# THIS LINE OF CODE FILTERS THE FAULT CODE TYPE BY THE 3 MOST COMMON
temp <- filter(NOINFO, FaultCodeType %in% tail(names(sort(table(NOINFO$FaultCodeType))),3)) # takes the 3 most common faults







#######################################################

# VIOLIN PLOT; Fault code type by active power and temperature

G7 <- NOINFO %>%
  ggplot( aes(x=FaultCodeType, y=AverageActivePower, fill=FaultCodeType)) + 
  geom_violin() +
  scale_fill_brewer(palette = "Paired") +
  labs(title = "Fault code type by Active power")+
  theme_dark()+
  theme(plot.title = element_text(hjust = 1, size = 16),
        axis.title.x = element_text(size = 14),
        axis.title.y = element_text(size = 14),
        axis.text = element_text(size = 5),
        legend.position = 'none')

G9 <- NOINFO %>%
  ggplot( aes(x=FaultCodeType, y=AverageAmbientTemperature, fill=FaultCodeType)) + 
  geom_violin() +
  scale_fill_brewer(palette = "Paired") +
  labs(title = "Fault code type by Ambient Temperature")+
  theme_dark()+
  theme(plot.title = element_text(hjust = 1, size = 16),
        axis.title.x = element_text(size = 14),
        axis.title.y = element_text(size = 14),
        axis.text = element_text(size = 5),
        legend.position = 'none')
  
grid.arrange(G7,G9)


###################################


# A basic scatterplot with color depending on fault code type 
ggplot(NOINFO, aes(x=FaultCodeType, y=SdHydraulicPressure, fill =FaultCodeType)) + 
  geom_point(size=2) +
  theme_dark()+
  scale_fill_brewer(palette = "Paired")



#################################################################
































# A basic scatterplot with color 

# this will filter the 3 most common turbines?
turb <- filter(new_data_complete_merged2, TurbineId %in% tail(names(sort(table(new_data_complete_merged2$TurbineId))),3)) # takes the 3 most common faults

# THIS LINE OF CODE FILTERS THE FAULT CODE TYPE BY THE 3 MOST COMMON
temp <- filter(new_data_complete_merged2, FaultCodeType %in% tail(names(sort(table(new_data_complete_merged2$FaultCodeType))),3))
                                                                        
# this shall be refined further 
# HS AND IMS Bearing temp by turbineID
ggplot(finaldataset, aes(x=AverageGearboxHSBearingTemperature, y=AverageGearboxIMSBearingTemperature, color=TurbineId)) + 
  geom_point(size=1) +
  scale_fill_brewer(palette = "Paired")+
  labs(title = "TurbineID by HS and IMS Bearing Temperature")+
  theme_dark()
# HS AND IMS Bearing temp by faultcodetype

ggplot(finaldataset, aes(x=AverageGearboxHSBearingTemperature, y=AverageGearboxIMSBearingTemperature, fill=FaultCodeType)) + 
  geom_point(size=1) +
  scale_fill_brewer(palette = "Paired")+
  labs(title = "Fault code type by HS and IMS Bearing Temperature")+
  theme_dark()




####################################################################


# plot showing the bearing temps by fault code types
# THIS IS TO GET RID OF INFORMATIONAL AND NA'S!!!!
NOINFO <- new_data_complete_merged2 %>%
  filter(!FaultCodeType %in% c("Informational", "NA", "Human Performance")) %>%
  na.omit()

#####################################
# this one is good. Need to get rid of informational and change the color scheme....
# this will filter faultcodetype
FAULTCODETYPE <- filter(new_data_complete_merged2, FaultCodeType %in% tail(names(sort(table(new_data_complete_merged2$FaultCodeType))),2)) # takes the 3 most common faults

# I want to make a bubble plot 
# Most basic bubble plot
# this is ok.. but needs to be better 
# should filter the faultcodetypes
ggplot(NOINFO, aes(x=AverageWindspeedKnots, y=MaxGust, color = FaultCodeType)) +
  geom_point(alpha=0.7)+
  scale_fill_manual(values =cbPalette)+
  labs(title = "Fault code type by Ambient Temp and Windspeed in Knots")+
    theme_dark()

###################################

# try linking humidity to electrical faults !  

linking <- finaldataset %>%
  filter(!FaultCodeType %in% c("Informational", "Balance of Plant", "Brake","Control System", "Drive Train", "External", "Gear Box", "Generator/Exciter","Human Performance", "Hydraulic System", "Pitch System", "Rotor", "Yaw System", "NA"))


ggplot(linking,aes(x= MaxTempF, y =MinTempF, color = FaultCodeType ))+
  geom_point(alpha=0.7)+
  theme_classic()

ggplot(linking,aes(x= MaxRelativeHumidity, y =MinRelativeHumidity, color = FaultCodeType ))+
  geom_point(alpha=0.7)+
  theme_classic()


#########################################

# making a bubble plot with the new weather data merged with the other data


ggplot(NOINFO, aes(x=AverageAmbientTemperature, y=MaxRelativeHumidity, size = MaxGust, color = TurbineId)) +
  geom_point(alpha=0.7)+
  scale_color_brewer(palette = "Paired")+
  labs(title = "TurbineID by ambient temp and max humidity sized by max wind gust")+
  theme_grey()


  
  ############################################################
  ############################################################
  ############################################################
  ############################################################
  
  
# Going to now do Visuals with the new filter that gets ride of informational, NA and human performance 
NOINFO <- new_data_complete_merged2 %>%
    filter(!FaultCodeType %in% c("Informational", "NA")) %>%
    na.omit()
######################################################################

# Bubble plot # 
# Most basic bubble plot - 
PLOT9 <- ggplot(NOINFO, aes(x=AverageActivePower, fill = FaultCodeType)) +
  geom_boxplot(alpha=0.7, size = 1)+
    scale_fill_manual(values=cbPalette) +
    labs(title = "FaultCodeType by Avg Active Power")+
    theme_dark()

PLOT10 <- ggplot(NOINFO, aes( x=AverageGeneratorRPM, fill = FaultCodeType)) +
  geom_boxplot(alpha=0.7, size = 1)+
  scale_fill_manual(values=cbPalette) +
  labs(title = "FaultCodeType by Avg GeneratorRPM")+
  theme_dark()

grid.arrange(PLOT9,PLOT10)
 

#####################################################################
  
# Animation: RPM by Fault code type# 
# WORKING - NEEDS MORE ATTENTION !

ANIMATION <- ggplot(NOINFO,aes(x = MaxActivePower)) + 
  geom_point(aes( y =FaultCodeType, color = "Faultcode")) +
  transition_time(date) +
  labs(title = 'Day: {frame_time}')
animate(
  plot = ANIMATION,
  render = gifski_renderer(),
  height = 600,
  width = 800, 
  duration = 5,
  fps = 20)

anim_save('my_gif6.gif')

finaldataset$FaultCodeOccurs <- as.factor(finaldataset$FaultCodeOccurs)

#Basic geom_point graphs showing nonlinearity in variable relationships
ggplot(data=finaldataset)+geom_point(aes(x=MeanPower,y=MeanGeneratorRPM,color=FaultCodeOccurs), size = 1)+
  scale_color_manual(values = c("#000000","#FF0000"))+
  scale_y_continuous(expand = c(0,0))+ # this makes the data to be on 0,0 
  labs(title = "MeanPower and MeanGeneratorRPM by FaultCodeOccurs")+
  theme(legend.key.size = unit(10, "cm"))+
  theme_bw()





ggplot(data=finaldataset)+geom_bin2d(aes(x=MeanPower,y=MeanGeneratorRPM))+
  scale_fill_viridis_c(option="magma")+
  labs(title = "MeanPower and MeanGeneratorRPM by FaultCodeOccurs")

ggplot(data=finaldataset)+geom_bin2d(aes(x=MeanOilTemp,y=MeanGeneratorRPM))+
  scale_fill_viridis_c(option="magma")+
  labs(title = "MeanOilTemp and MeanGeneratorRPM by FaultCodeOccurs")
