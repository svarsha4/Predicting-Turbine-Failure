rm(list=ls())

library(fmsb)
library(randomForest)
library(pROC)
library(ggplot2)
library(lubridate)
library(tidyverse)
library(gridExtra)
library(dplyr)

#This code makes a random forest model to try and predict whether a fault code will occur within the next
#24 hours

#Load in the data, and remove some of the "cheater" columns that, in the future, data wouldn't know
merged_data <- read.csv("final_dataset2.csv", stringsAsFactors = TRUE)

merged_data <- subset(merged_data, select = -c(TurbineId, RoundedDateTime, date, MaxGustRecordedTime, TimeUntilFault, FaultEventStart,
                                              FaultCodeNumber, FaultCodeDescription, FaultCodeType, EndTime))
merged_data$FaultCodeOccurs <- as.factor(merged_data$FaultCodeOccurs)

#create a train-test split, with the model being trained on 70% of the data, and tested on the other 30%
RNGkind(sample.kind = "default")
set.seed(45698654)
train.idx <- sample(x = 1:nrow(merged_data), size = floor(.7*nrow(merged_data)))
train.df <- merged_data[train.idx,]
test.df <- merged_data[-train.idx,]

#creates an initial forest just for proof of concept intially
myforest <- randomForest(FaultCodeOccurs ~.,
                         data = train.df,
                         ntree = 1000,
                         mtry = 6,
                         importance = TRUE)

#pi_hat is a list. Each element is a prediction by the random forest about, how likely is that sensor
#reading to have a fault event in the next 24 hours
pi_hat <- predict(myforest, test.df, type = "prob")[,"1"]
#create an ROC curve
rocCurve <- roc(response = test.df$FaultCodeOccurs,
                predictor = pi_hat,
                levels = c(0, 1))

plot(rocCurve, print.thres = TRUE, print.auc = TRUE)
#The ideal pi* appears to be .438. At that level:
#Specificity = .896
#Sensitivity = .880
#AUC = .958

#making a confusion matrix with pi* = .438
y_hat <- as.factor(ifelse(pi_hat>.438, 1, 0))
table(y_hat, test.df$FaultCodeOccurs)

#view a variable importance plot
varImpPlot(myforest, type = 1, main = "Variable Importance")


#create a dataframe to store the OOB error rate of the forest when made with each possible value of mtry
mtry <- c(1:37)
keeps <- data.frame(m = rep(NA, length(mtry)),
                    OOB_err_rate = rep(NA, length(mtry)))
#create a loop to create a forest for each value of mtry, and store its OOB error rate
for (idx in 1:length(mtry) ){
  print(paste0("Fitting forest with m = ", mtry[idx]))
  tempforest <- randomForest(FaultCodeOccurs ~.,
                             data = train.df,
                             ntree = 1000,
                             mtry = mtry[idx])
  keeps[idx, "m"] <- mtry[idx]
  keeps[idx, "OOB_err_rate"] <- mean(predict(tempforest)!=train.df$FaultCodeOccurs)
}

#plot the OOB error rates and their value of m to find the lowest OOB error rate
ggplot(data = keeps) +
  geom_line(aes(x = m, y = OOB_err_rate)) +
  geom_point(aes(x = m, y = OOB_err_rate)) +
  scale_x_continuous(breaks = mtry) +
  labs(x = "m", y = "Out of Bag Error Rate") +
  theme_bw()

view(keeps)
#best mtry is 20

#create our final forest with an mtry of 20
NoTurbineForest <- randomForest(FaultCodeOccurs ~.,
                         data = train.df,
                         ntree = 1000,
                         mtry = 20,
                         importance = TRUE)

#create the ROC curve for the final model
pi_hat <- predict(NoTurbineForest, test.df, type = "prob")[,"1"]
rocCurve <- roc(response = test.df$FaultCodeOccurs,
                predictor = pi_hat,
                levels = c("0", "1"))

plot(rocCurve, print.thres = TRUE, print.auc = TRUE)
#The ideal pi* appears to be .418. At that level:
#Specificity = .890
#Sensitivity = .903
#AUC = .964

#making a confusion matrix with pi* = .487
y_hat <- as.factor(ifelse(pi_hat>.418, 1, 0))
table(y_hat, test.df$FaultCodeOccurs)

#view the variable importance plot for the final model
varImpPlot(NoTurbineForest, type = 1, main = "Variable Importance")

#save the forest so we don't have to rerun the model every time
save(NoTurbineForest, file = "NoTurbineForest.RData")