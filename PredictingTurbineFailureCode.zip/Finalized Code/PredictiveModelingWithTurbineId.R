rm(list = ls())

#loading packages
library(ggplot2)
library(lubridate)
library(tidyverse)
library(gridExtra)
library(dplyr)
library(hrbrthemes)
library(magrittr)
library(randomForest)
library(pROC)
library(imputeTS)
library(MASS)
library(rlist)
library(e1071)
library(caTools)
library(class)

merged_data <- read.csv("final_dataset.csv")
View(merged_data)

#Before we create our first random forest model (only for sensor readings), let's first remove any columns
#pertaining to fault codes (besides FaultCodeOccurs), since they are not necessary. Additionally, let's remove all
#the weather metrics since they are not currently necessary for this specific random forest modeling either. Finally,
#let's remove all the date-time columns, since they are not necessary either
merged_data <- subset(merged_data, select=-c(RoundedDateTime, date, 
                                             TimeUntilFault, FaultEventStart, FaultCodeNumber, 
                                             FaultCodeDescription, FaultCodeType, EndTime, MaxGustRecordedTime))




ncol(merged_data) #there is a total of 38 predictor variables, so that means we will
#sample sqrt(38) x's for each tree in the baseline random forest


#Now, we are ready to create our baseline random forest

#Before we do that though, let's convert the columns TurbineId and FaultCodeOccurs as factors
merged_data$FaultCodeOccurs <- as.factor(merged_data$FaultCodeOccurs)
merged_data$TurbineId <- as.factor(merged_data$TurbineId)

#set the seed
RNGkind(sample.kind = "default")
set.seed(2291352)
#split data into training and testing data
#Note: 70% of training data and 30% of testing data
train.idx <- sample(x = 1:nrow(merged_data), size = .7*nrow(merged_data))
train.df <- merged_data[train.idx,]
test.df <- merged_data[-train.idx,]
View(train.df)
#fitting the actual baseline random forest
baseline_forest <- randomForest(FaultCodeOccurs ~ . ,
                                data = train.df,
                                ntree = 1000,
                                mtry = sqrt(38), #sqrt(38) as number of x's to sample for each tree
                                importance = TRUE)

#confusion matrix of the baseline forest
baseline_forest
#The OOB error rate is around 5.56%. 
#However, let's still see if tuning the baseline random forest will result in the OOB error rate decreasing.


#Now, let's tune our baseline random forest to see if we can decrease the OOB Error Rate
#In order to tune m, we must first consider all of our explanatory variables, which
#in this case are 38
mtry <- c(1:38)

#Now, the actual process of tuning m begins:

#1. making empty data frame for m and OOB error rate
keeps <- data.frame(m = rep(NA, length(mtry)),
                    OOB_error_rate = rep(NA, length(mtry)))

#2. fit forests with different values for mtry to tune mtry.
for (idx in 1:length(mtry)){
  
  print(paste0("Fitting m = ", mtry[idx]))
  
  tempforest <- randomForest(FaultCodeOccurs ~ . ,
                             data = train.df,
                             ntree = 1000,
                             mtry = mtry[idx]) #mtry is varying with idx
  
  
  #record the corresponding OOB error
  keeps[idx, "m"] <- mtry[idx]
  keeps[idx, "OOB_error_rate"] <-mean(predict(tempforest) != train.df$FaultCodeOccurs)
  
}

#3. checking if keeps filled correctly
keeps

#4. plot m vs OOB error rate
ggplot(data = keeps) +
  geom_line(aes(x = m, y = OOB_error_rate)) +
  scale_x_continuous(breaks = c(0:38)) +
  labs(x = "m (mtry): # of x variables sampled",
       y = "OOB Error Rate")
#It appears that the OOB error rate is the smallest when m-try = 18.

#Step 5: Fitting our finalized random forest
#Using the information just obtained above from tuning our baseline
#random forest, let's fit our final tuned random forest
finalForest <- randomForest(FaultCodeOccurs ~ .,
                            data = train.df,
                            ntree = 1000,
                            mtry = 18, #based on tuning above
                            importance = TRUE)


#Let's look at the finalForest and compute it's new accuracy and OOB error
finalForest
#It appears that the OOB error rate is now around 5.27%, which is a bit smaller than the 6.31% recorded for the baseline random forest.

#Let's save the results of that forest into a csv file
save(finalForest, file = "TurbineForest.RData")

#Now, having fit our finalized random forest, let's plot an ROC Curve

#However, before that is done, let's create a new
#variable called pi_hat that stores the probabilities of all the positive
#events (which in this case are the events of 1 -- where FaultCodeOccurs is 1)
pi_hat <- predict(finalForest, test.df, type = 'prob')[,"1"]

#Plot ROC curve
rocCurve <- roc(response = test.df$FaultCodeOccurs,
                predictor = pi_hat,
                levels = c("0","1"))
plot(rocCurve, print.thres = TRUE, print.auc = TRUE)
#Based on the results above, we have a specificity of 0.958. This means that given the model DOES NOT predict that a fault code occurs at most
#24 hours from a recorded sensor reading, the model indeed predicts that accurately 95.8% of the time. Meanwhile, the sensitivity is 0.941. 
#This means that
#given the model predicts that a fault code DOES occur at most 24 hours from a recorded sensor reading, the model indeed predicts that
#accurately 94.1% of the time. The area under the curve (AUC) is 0.989. 
#The specificity and sensitivity are pretty decent given the amount of the data
#and explanatory variables we have, so to a large extent, this ROC Curve signifies that this random forest model is a 
#fairly accurate predictive model.

#Now, let's extract the optimal pi* star determined from the ROC Curve above
pi_star <- coords(rocCurve, "best", ret = "threshold")$threshold[1]
pi_star
test.df$forest_pred <- as.factor(ifelse(pi_hat > pi_star, 1, 0))
View(test.df)
write.csv(test.df, "test_data_randomForest_with_TurbineId.csv")

#Making a confusion matrix with the optimal pi star
y_hat <- as.factor(ifelse(pi_hat > pi_star, 1, 0))
table(y_hat, test.df$FaultCodeOccurs)

#Creating a variable importance plot:

#Finally, it would be helpful for us to know which variables are the most
#important for our final random forest model.
varImpPlot(finalForest, type = 1)
#Based on the results from the graph, the variables
#TurbineId, AverageAmbientTemperature, MaxAmbientTemperature, and SdActivePower
#are the most effective at predicting FaultCodeOccurs.