rm(list=ls())

library(ggplot2)
library(lubridate)
library(tidyverse)
library(gridExtra)
library(dplyr)
library(fmsb)

#This code takes the sensor readings, as well as the fault events, and attaches each sensor readings 
#to the next fault event that takes place on the same turbine

#Much of this code was inspired by code from Drew Covington

#Load in the fault events data and rename the datetime column
faultevents <- read.csv("faultevents.csv", stringsAsFactors = TRUE)
colnames(faultevents)[2] = "FaultEventStart"

#This removes some of the fault events that aren't really faults
#The sensor readings should not be able to predict these very well, because they are unrelated to the 
#readings
table(faultevents$FaultCodeDescription)
not_actually_a_fault_index <- grep('Stopped Due To Power Up Delay|Local, Ad-Hoc / Repair Work|Stopped, Untwisting Cables|Local, Scheduled Service Work', faults$FaultCodeDescription)
faultevents <- faults[-c(not_actually_a_fault_index),]

#Read in the sensor data
merged_data <- read.csv("sensor_weather_imputed.csv", stringsAsFactors = TRUE)

# order the sensor and fault data by turbine and time
merged_data <- merged_data %>%
  arrange(TurbineId, RoundedDateTime)

faultevents <- faultevents %>%
  arrange(TurbineId, FaultEventStart) 

#Merge the two datasets on turbine id
#This will create a massive data frame, with one row for each combination of a sensor reading row and each 
#fault event that occurs on the same turbine
#we will then take out certain rows to get the data frame we want

merged_data <- merge(x = merged_data, y = faultevents, by = c("TurbineId"), all.x = TRUE)


#make sure the dates are in the same format
merged_data$RoundedDateTime = ymd_hms(merged_data$RoundedDateTime)
merged_data$FaultEventStart = ymd_hms(merged_data$FaultEventStart)
merged_data$EndTime = ymd_hms(merged_data$EndTime)


#Get rid of rows where the work order starts before the date of the measurements
merged_data <- merged_data %>% filter(RoundedDateTime <= FaultEventStart)



#already ordered by time earlier, so now, if we keep only the first instance of each TurbineId and 
#RoundedDateTime, this will leave us with only the rows where a sensor reading is associated with the
#first fault event that starts after the time of the sensor reading, which is, the next fault event

merged_data <- merged_data[!duplicated(merged_data[c("TurbineId","RoundedDateTime")]),]



#create time until fault variable (hours), as well as a fault code occurs, which is a 1 if the time until
#fault is 24 or less, and 0 otherwise

merged_data$TimeUntilFault <- NA
merged_data$TimeUntilFault <- as.numeric(difftime(merged_data$FaultEventStart, merged_data$RoundedDateTime, units="hours"))
merged_data$FaultCodeOccurs <- ifelse(merged_data$TimeUntilFault <=24, 1, 0)

#save the dataframe, which is our final dataset.
write.csv(merged_data, "final_dataset.csv", row.names = FALSE)
