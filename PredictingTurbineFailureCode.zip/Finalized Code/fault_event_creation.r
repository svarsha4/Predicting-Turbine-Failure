rm(list=ls())

library(ggplot2)
library(lubridate)
library(tidyverse)
library(gridExtra)
library(dplyr)
library(fmsb)

#Most of this code was borrowed from Jack Schwartz of another group
#The purpose of this code is to account for fault events. There are instances where a fault code will
#occur every 5 minutes or so for a few days straight. In reality, these separate fault codes are really 
#all part of the same event. This can result in some misleading analysis, where, for example, 
#a row of sensor data will be associated with a fault code pinging, when the real issue actually started
#a couple of days ago. This code combines fault codes of the same description into fault events.
#If two fault codes occur on the same turbine, with the same fault code description, within 6 hours of each
#other, then they are put into the same fault event. We store the Turbine, start time, fault code number,
#description, type, and fault event endtime


#Loops through and reads in the fault codes in a very similar way as we did with the sensor readings
faultcode_files <- list.files("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Fault Status Codes/Fault Status Codes")
faultcode_files_amount <- length(list.files("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Fault Status Codes/Fault Status Codes"))
fcf <- read.csv(paste0("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Fault Status Codes/Fault Status Codes/", faultcode_files[2]), header=FALSE)
for(x in 3:faultcode_files_amount) {
  print(paste0("Cleaning data file number: ", x))
  fcf <- rbind(fcf, read.csv(paste0("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Fault Status Codes/Fault Status Codes/", faultcode_files[x]), header= FALSE))
}
fcf$V2 <- ymd_hms(fcf$V2)
fcf <- subset(fcf, select = -c(V3, V5))
FC_data_working <- fcf
rm(fcf, faultcode_files, faultcode_files_amount, x)

#we end up with a data frame called FC_data_working

#renaming columns
colnames(FC_data_working)[1]="Turbine"
colnames(FC_data_working)[2]="DayTime"
colnames(FC_data_working)[3]="OEMStatusCode"
colnames(FC_data_working)[4]="FCDescription"
colnames(FC_data_working)[5]="FCType"

#adjusting format / type of the DayTime and Date columns
FC_data_working$DayTime <- ymd_hms(FC_data_working$DayTime)


#ordering data by turbine, fault code description, then date
FC_data_working <- FC_data_working %>%
  arrange(Turbine, FCDescription, DayTime) %>%
  group_by(Turbine)


#creating a process to turn all of the faults into fault events
# this is done to get rid of repeat fault code sent for the same turbine only a few minutes later
mylist  = list()
j = 1
m= 0
last_time = FC_data_working[1,]$DayTime
#loops through every fault
for (i in 1:nrow(FC_data_working)){
  #keeps track of the row, turbine, fault description, and time of the current row and the next row
  rowinfo = FC_data_working[j,]
  turbine = rowinfo$Turbine
  description = rowinfo$FCDescription
  time = rowinfo$DayTime
  
  next_line = FC_data_working[i,]
  next_turbine = next_line$Turbine
  next_description = next_line$FCDescription
  next_time = next_line$DayTime
  
  #If the turbines don't match, the descriptions don't match, or the time difference is too large, then we end the fault event
  if (turbine != next_turbine | description != next_description | as.numeric(difftime(next_time, last_time, units="hours"))>6){ #change the 6 or "hours" if you want to change the minimum time difference to create a new fault event
    j = j + m
    m=0
    rowinfo$FaultEndTime = FC_data_working[i-1,]$DayTime
    mylist <- list.append(mylist, rowinfo)
  }
  #This ends the fault event associated with the last row of fault data
  if (i == nrow(FC_data_working)){
    rowinfo$FaultEndTime = FC_data_working[i,]$DayTime
    mylist <- list.append(mylist, rowinfo)
  }
  m = m + 1
  last_time = FC_data_working[i,]$DayTime
}

#creating a data frame from the list
FCdata_final <- do.call(rbind, mylist)
colnames(FCdata_final) <- c("TurbineId", "RoundedDateTime", "FaultCodeNumber", "FaultCodeDescription", "FaultCodeType", "EndTime")

#saves the final data frame faultevents.csv
write.csv(FCdata_final, "faultevents.csv", row.names = FALSE)