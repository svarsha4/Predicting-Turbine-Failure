rm(list=ls())

library(imputeTS)

#most of this code was taken from Theresa Sheridan of a different group, and imputes the missing values using Kalman filtering

#loading in the data and formatting dates
merged_data <- read.csv("sensor_weather.csv", stringsAsFactors = TRUE)
merged_data$RoundedDateTime <- ymd_hms(merged_data$RoundedDateTime)
merged_data$date <- ymd(merged_data$date)
merged_data$MaxGustRecordedTime <- ymd_hms(merged_data$MaxGustRecordedTime)


#Since we have missing values in almost every sensor reading column, let's impute those missing values.
#First, let's get all the unique turbine ids we have
unique_turbines <- unique(merged_data$TurbineId)
#Next, let's sort the data by turbine and date time
merged_data <- arrange(merged_data, TurbineId, RoundedDateTime)
#Then, let's check to see how many columns we have in total to decide which ones to impute
str(merged_data)  #41 columns in total
#Then, let's specify which columns we want to impute missing values from: columns 3 to 30
to_impute <- colnames(merged_data)[c(3:30)]
#Finally, let's iterate through each of the turbines then through each column we want to impute
for (i in 1:length(unique_turbines)){
  print(paste0("imputing turbine", i))
  #subset because there are so many missing values, so by doing it by turbine, you make it more accurate
  x = subset(merged_data, TurbineId == unique_turbines[i])
  
  for (j in to_impute){
    
    print(paste0("imputing column", j))
    
    # use this time series imputing algorithm to fill in missing values
    
    imp = na_kalman(x[,j])
    
    # put data back into bhedata and we have a new dataframe that is all imputed!!!
    
    merged_data[merged_data$TurbineId == unique_turbines[i],j] <- imp
    
  }
  
}


#Verification that we don't have any na values anymore
summary(merged_data)
write.csv(merged_data, "sensor_weather_imputed.csv", row.names=FALSE)
