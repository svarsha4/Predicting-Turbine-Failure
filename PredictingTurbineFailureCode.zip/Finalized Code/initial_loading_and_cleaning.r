rm(list = ls())

#loading packages
library(ggplot2)
library(lubridate)
library(tidyverse)
library(gridExtra)
library(dplyr)
library(fmsb)

#This creates a list of all of the Active Power data files
activepower_files <- list.files("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Active Power/Active Power")
#Checks the length of the list for the purposes of knowing how long to make the loop
activepower_files_amount <- length(list.files("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Active Power/Active Power"))
#creates a data frame based on the second active power file. It uses the second file because the first is empty
apf <- read.csv(paste0("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Active Power/Active Power/", activepower_files[2]), header=FALSE)
#loops through all of the active power files, adding them to the first one, and creating one massive active power dataframe
for(x in 3:activepower_files_amount) {
  print(paste0("Cleaning data file number: ", x))
  apf <- rbind(apf, read.csv(paste0("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Active Power/Active Power/", activepower_files[x]), header= FALSE))
}
#Turns V2 (the date time variable) from a string format into a date
apf$V2 <- ymd_hms(apf$V2)
#drops columns 3 and 5, which contain no information
apf <- subset(apf, select = -c(V3,V5))
#Create a new column called RoundedDateTime, which is a new version of V2 which is rounded to 30 minute intervals
apf['RoundedDateTime'] <- round_date(apf$V2, "30 mins")
#Now, there are multiple rows of data for each value of rounded date time. This combines them all into one
# and keeps the average, minimum, maximum, and standard deviation of the values during that 30 minute period
apf <- apf %>% group_by(V1, RoundedDateTime) %>% summarise(MeanPower = mean(V4), MinPower = min(V4), MaxPower = max(V4), SdPower = sd(V4))
#Drops the list of active power files and its length, as we no longer need it
rm("activepower_files", "activepower_files_amount")

#repeats the same process that we did for active power, but for ambient temperature
ambienttemp_files <- list.files("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Ambient Temperature/Ambient Temperature")
ambienttemp_files_amount <- length(list.files("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Ambient Temperature/Ambient Temperature"))
atf <- read.csv(paste0("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Ambient Temperature/Ambient Temperature/", ambienttemp_files[2]), header=FALSE)
for(x in 3:ambienttemp_files_amount) {
  print(paste0("Cleaning data file number: ", x))
  atf <- rbind(atf, read.csv(paste0("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Ambient Temperature/Ambient Temperature/", ambienttemp_files[x]), header= FALSE))
}
atf$V2 <- ymd_hms(atf$V2)
atf <- subset(atf, select = -c(V3,V5))
atf['RoundedDateTime'] <- round_date(atf$V2, "30 mins")
atf <- atf %>% group_by(V1, RoundedDateTime) %>% summarise(MeanAmbientTemp = mean(V4), MinAmbientTemp = min(V4), MaxAmbientTemp = max(V4), SdAmbientTemp = sd(V4))
rm("ambienttemp_files", "ambienttemp_files_amount")

#This now creates a new data frame that is a full join of the active power and ambient temperature data frames
turbineinfo <- full_join(apf, atf, by=c("V1", "RoundedDateTime"))
#Now, we drop the active power and ambient temperature data frames, as they are now part of turbineinfo
rm(apf, atf)

#This process repeats for all of the sensor readings, with them being read in, aggregated to 30 minute intervals,
#and then doing a full_join between the given sensor reading data and the turbine info data frame.
gearboxhs_files <- list.files("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Gearbox HS Bearing/Gearbox HS Bearing")
gearboxhs_files_amount <- length(list.files("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Gearbox HS Bearing/Gearbox HS Bearing"))
ghsf <- read.csv(paste0("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Gearbox HS Bearing/Gearbox HS Bearing/", gearboxhs_files[2]), header=FALSE)
for(x in 3:gearboxhs_files_amount) {
  print(paste0("Cleaning data file number: ", x))
  ghsf <- rbind(ghsf, read.csv(paste0("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Gearbox HS Bearing/Gearbox HS Bearing/", gearboxhs_files[x]), header= FALSE))
}
ghsf$V2 <- ymd_hms(ghsf$V2)
ghsf <- subset(ghsf, select = -c(V3,V5))
ghsf['RoundedDateTime'] <- round_date(ghsf$V2, "30 mins")
ghsf <- ghsf %>% group_by(V1, RoundedDateTime) %>% summarise(MeanHSBearingTemp = mean(V4), MinHSBearingTemp = min(V4), MaxHSBearingTemp = max(V4), SdHSBearingTemp = sd(V4))
rm("gearboxhs_files", "gearboxhs_files_amount")

turbineinfo <- full_join(turbineinfo, ghsf, by=c("V1", "RoundedDateTime"))
rm("ghsf")

#The Gearbox IMS Bearing Temperature data is somewhat different, as it is split across two folders
#To handle this, we read in the data from each folder, then combined them into one file, and then merged
#that with turbineinfo
gearboxims1_files <- list.files("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Gearbox IMS Bearing 1/Gearbox IMS Bearing 1")
gearboxims1_files_amount <- length(list.files("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Gearbox IMS Bearing 1/Gearbox IMS Bearing 1"))
gimsf1 <- read.csv(paste0("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Gearbox IMS Bearing 1/Gearbox IMS Bearing 1/", gearboxims1_files[2]), header=FALSE)
for(x in 3:gearboxims1_files_amount) {
  print(paste0("Cleaning data file number: ", x))
  gimsf1 <- rbind(gimsf1, read.csv(paste0("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Gearbox IMS Bearing 1/Gearbox IMS Bearing 1/", gearboxims1_files[x]), header= FALSE))
}
gimsf1$V2 <- ymd_hms(gimsf1$V2)
gimsf1 <- subset(gimsf1, select = -c(V3,V5))

gearboxims2_files <- list.files("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Gearbox IMS Bearing 2/Gearbox IMS Bearing 2")
gearboxims2_files_amount <- length(list.files("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Gearbox IMS Bearing 2/Gearbox IMS Bearing 2"))
gimsf2 <- read.csv(paste0("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Gearbox IMS Bearing 2/Gearbox IMS Bearing 2/", gearboxims2_files[5]), header=FALSE)
for(x in 6:gearboxims2_files_amount) {
  print(paste0("Cleaning data file number: ", x))
  gimsf2 <- rbind(gimsf2, read.csv(paste0("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Gearbox IMS Bearing 2/Gearbox IMS Bearing 2/", gearboxims2_files[x]), header= FALSE))
}
gimsf2$V2 <- ymd_hms(gimsf2$V2)
gimsf2 <- subset(gimsf2, select = -c(V3,V5))
gimsf <- rbind(gimsf1, gimsf2)
gimsf['RoundedDateTime'] <- round_date(gimsf$V2, "30 mins")
gimsf <- gimsf %>% group_by(V1, RoundedDateTime) %>% summarise(MeanIMSBearingTemp = mean(V4), MinIMSBearingTemp = min(V4), MaxIMSBearingTemp = max(V4), SdIMSBearingTemp = sd(V4))
rm("gearboxims1_files", "gearboxims1_files_amount", "gearboxims2_files", "gearboxims2_files_amount")

turbineinfo <- full_join(turbineinfo, gimsf, by=c("V1", "RoundedDateTime"))
rm("gimsf", "gimsf1", "gimsf2")

gearboxoil_files <- list.files("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Gearbox Oil/Gearbox Oil")
gearboxoil_files_amount <- length(list.files("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Gearbox Oil/Gearbox Oil"))
gof <- read.csv(paste0("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Gearbox Oil/Gearbox Oil/", gearboxoil_files[2]), header=FALSE)
for(x in 3:gearboxoil_files_amount) {
  print(paste0("Cleaning data file number: ", x))
  gof <- rbind(gof, read.csv(paste0("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Gearbox Oil/Gearbox Oil/", gearboxoil_files[x]), header= FALSE))
}
gof$V2 <- ymd_hms(gof$V2)
gof <- subset(gof, select = -c(V3,V5))
gof['RoundedDateTime'] <- round_date(gof$V2, "30 mins")
gof <- gof %>% group_by(V1, RoundedDateTime) %>% summarise(MeanOilTemp = mean(V4), MinOilTemp = min(V4), MaxOilTemp = max(V4), SdOilTemp = sd(V4))
rm("gearboxoil_files", "gearboxoil_files_amount")

turbineinfo <- full_join(turbineinfo, gof, by=c("V1", "RoundedDateTime"))
rm("gof")

rpm_files <- list.files("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Generator RPM/Generator RPM")
rpm_files_amount <- length(list.files("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Generator RPM/Generator RPM"))
rpmf <- read.csv(paste0("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Generator RPM/Generator RPM/", rpm_files[2]), header=FALSE)
for(x in 3:rpm_files_amount) {
  print(paste0("Cleaning data file number: ", x))
  rpmf <- rbind(rpmf, read.csv(paste0("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Generator RPM/Generator RPM/", rpm_files[x]), header= FALSE))
}
rpmf$V2 <- ymd_hms(rpmf$V2)
rpmf <- subset(rpmf, select = -c(V3,V5))
rpmf['RoundedDateTime'] <- round_date(ymd_hms(rpmf$V2), "30 mins")
rpmf <- rpmf %>% group_by(V1, RoundedDateTime) %>% summarise(MeanGeneratorRPM = mean(V4), MinGeneratorRPM = min(V4), MaxGeneratorRPM = max(V4), SdGeneratorRPM = sd(V4))
rm("rpm_files", "rpm_files_amount")

turbineinfo <- full_join(turbineinfo, rpmf, by=c("V1", "RoundedDateTime"))
rm("rpmf")

hp_files <- list.files("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Hydraulic Pressure/Hydraulic Pressure")
hp_files_amount <- length(list.files("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Hydraulic Pressure/Hydraulic Pressure"))
hpf <- read.csv(paste0("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Hydraulic Pressure/Hydraulic Pressure/", hp_files[5]), header=FALSE)
for(x in 6:hp_files_amount) {
  print(paste0("Cleaning data file number: ", x))
  hpf <- rbind(hpf, read.csv(paste0("Wind Turbine Data Batch 2/Wind Turbine Data Batch 2 - Hydraulic Pressure/Hydraulic Pressure/", hp_files[x]), header= FALSE))
}
hpf$V2 <- ymd_hms(hpf$V2)
hpf <- subset(hpf, select = -c(V3,V5))
hpf['RoundedDateTime'] <- round_date(ymd_hms(hpf$V2), "30 mins")
hpf <- hpf %>% group_by(V1, RoundedDateTime) %>% summarise(MeanHydraulicPressure = mean(V4), MinHydraulicPressure = min(V4), MaxHydraulicPressure = max(V4), SdHydraulicPressure = sd(V4))
rm("hp_files", "hp_files_amount")

turbineinfo <- full_join(turbineinfo, hpf, by=c("V1", "RoundedDateTime"))
rm("hpf")

#We chose not to include the windspeed data, as it was very sparse, and we had access to windspeed data
#through the weather data.

#After loading in all of the sensor readings (except windspeed), and merging them into one large data frame,
#we create a new csv called all_sensor.csv
write.csv(turbineinfo, "all_sensor.csv", row.names = FALSE)
