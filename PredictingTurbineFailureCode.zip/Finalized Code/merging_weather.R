rm(list=ls())

library(fmsb)
library(randomForest)
library(pROC)
library(ggplot2)
library(lubridate)
library(tidyverse)
library(gridExtra)
library(dplyr)

#This weather data was supplied by Landon Norkus, from different group
weather <- read.csv("weather_data.csv", stringsAsFactors = TRUE)

#changes the date column from a string to a date format
weather$date <- ymd(weather$date)
table(weather$date)
summary(weather)

#Since we are looking at sensor readings recorded starting in June of 2022, we don't need any columns pertaining to snow
weather <- subset(weather, select=-c(snow, snowd))

#Let's remove several other columns as well that are not necessary
weather <- subset(weather, select=-c(station, X, temp_hour, min_feel, max_feel, avg_feel, max_drct, id, name))
is.na(weather$min_rstage) #all missing data
summary(weather) #all missing data for max_rstage as well; all false values for precip_est and tmpf_est
weather <- subset(weather, select=-c(max_rstage, min_rstage, precip_est, tmpf_est, vector_avg_drct))


#Let's create a separate column called date in the merged_data, so that we can merge the weather data to the merged_data
merged_data <- read.csv("all_sensor.csv", stringsAsFactors = TRUE)
#this takes the first 10 characters in the datetime string, which just returns the date, and creates a new date column
merged_data$date <- ymd(substr(merged_data$RoundedDateTime, 1, 10))

#Now, we are ready to merge the data
fully_merged_data <- left_join(merged_data, weather, by=c('date'), multiple='all')
summary(fully_merged_data)
fully_merged_data$max_gust_localts <- ymd_hms(fully_merged_data$max_gust_localts)
colnames(fully_merged_data)[32:41] <- c("MaxTempF", "MinTempF", "Precip", "MaxGust", "MinRelativeHumidity", "MaxRelativeHumidity", "MaxDewPointTempF", 
                                        "MinDewPointTempF", "MaxGustRecordedTime", "AverageWindspeedKnots")

colnames(fully_merged_data)[1] <- c("TurbineId")
write.csv(fully_merged_data, "sensor_weather.csv", row.names=FALSE)


